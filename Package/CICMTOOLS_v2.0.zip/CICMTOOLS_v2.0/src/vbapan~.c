/**********************************************************************/
//                                                                    //
// /****************************************************************/ //
// /*                                                              */ //
// /*                         VBAPAN                               */ //
// /*                                                              */ //
// /* Auteur: R�mi MIGNOT                                          */ //
// /*         El�ve ing�nieur T�l�com2 � l'ISPG                    */ //
// /*         (Institut Sup�rieur Polytechnique de Galil�e),       */ //
// /*         Universit� Paris13.                                  */ //
// /*                                                              */ //
// /* Date de creation:   21/07/03                                 */ //
// /* Version: 1.5        25/07/04                                 */ //
// /* Version: 2.0        07/04/12                                 */ //
// /*                                                              */ //
// /* R�alis� � la MSH Paris Nord (Maison des Sciences de l'Homme) */ //
// /*         en collaboration avec A.Sedes, B.Courribet           */ //
// /*         et J.B.Thiebaut,                                     */ //
// /*         CICM Universit� Paris8, MSH Paris Nord,              */ //
// /*         ACI Jeunes Chercheurs "Espaces Sonores".             */ //
// /*         Version 2.0 par Eliott PARIS                         */ //
// /*                                                              */ //
// /****************************************************************/ //
//                                                                    //
/**********************************************************************/


/**
 * Copyright (C) 2003-2004 R�mi Mignot, MSH Paris Nord,
 * 
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Library General Public License as published 
 * by the Free Software Foundation; either version 2 of the License.
 * 
 * This library is distributed in the hope that it will be useful, but WITHOUT 
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or 
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU Library General Public 
 * License for more details.
 * 
 * You should have received a copy of the GNU Library General Public License 
 * along with this library; if not, write to the Free Software Foundation, 
 * Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 * www.mshparisnord.org
 * rmignot@mshparisnord.org
 * eliott.paris@yahoo.fr
 */


/*Description:  Cet objet permet de spatialiser un son monoral
                � l'aide de N haut-parleurs situ�s autour
                de l'auditeur. La spatialisation se fait gr�ce �
                au syst�me VBAP (Vector Base Amplitude Panning).      */


/**** Version 2.0.0:
 *  methode float.
 *  methode assist.
 *  methode Main actualis�e.
 *  methode DSP revue.
 *  une seule methode perform pour le contr�le et le signal (plus besoin d'�crire s ou c, les 2 sont accept�s)
 *  optimis� si objet mut�;
 *  ne bug plus quand on r�instancie l'objet avec l'audio allum�.
 *  3�me arg (c/s => controle/signal) est sans effet : l'offset est donc soit le 3�me soit le 4�me arg (pour comptabilit�).
 *  gestion des erreurs mise � jour.
 *  16->64 hp Max.
 ****/


/**********************************************************************/
/*                            EN TETE                                 */
/**********************************************************************/
 
#include "ext.h"
#include "ext_obex.h"
#include "z_dsp.h"
#include <math.h>

#define   Nmax      64     //Nombre maximum de haut-parleurs,
#define   Ndefaut   4      //Nombre de haut-parleurs par d�faut,
#define   Xdefaut   0      //Valeur par d�faut de l'abscisse,
#define   Ydefaut   1      //Valeur par d�faut de l'ordonn�e,
#define   Phidefaut 1.5708F//Valeur par d�faut de l'angle,
#define   Rdefaut   1      //Distance par d�faut de la source,
#define   Rdisq     .5     //Rayon du disque central par d�faut,
#define   T_COS     4096   //Taille du tableau cosinus (puissance de 2),
#define   MASQUE    4095   //Masque pour le modulo = T_COS - 1,
#define   DTIME     10     //Temps d'interpolation par d�faut en ms,
#define   Pi        3.1415926535897932384F  //   = Pi
#define   I360      0.0027777777777777778F  //   = 1/360
#define   EPSILON   0.000001 //Crit�re pour tester si les flottants sont nuls




/**********************************************************/
/*         La classe                                      */
/**********************************************************/

void *vbapan_tilde_class;

typedef struct _vbapan_tilde
{  
  t_pxobject x_obj;       //Membre indispensable � Max,
	
  int	    base;         //Type de rep�re, 1->cart�sienne, 0->polaire, 		
  int       mute;         //1->entr�es signal mut�es, 0->non mut�es,
  int       Nout;         //Nombre de sorties,
  int       N;            //Nombre de haut-parleurs.
  
  float 	x,   y;       //Coordonn�es de la source en cart�sien,
  float     phi, r;       //Coordonn�es polaires de la source,
	float   c1, c2;       // coordonn�es entr�es dans l'inlet 1 et 2 (en contr�le ou signal);

  int       dtime;        //Temps d'interpolation en �chantillons,
  float     r_c;          //Rayon du disque central,
 
  float		G[Nmax];      //Tableau contenant les N gains des hp,
  float     teta[Nmax];   //Angles au centre des haut-parleurs,
  float     x_hp[Nmax];   //Abscisse de chaque haut-parleur,
  float     y_hp[Nmax];   //Ordonn�e des haut-parleurs,
  float     dst_hp[Nmax]; //distance des haut-parleurs,

  float     dG[Nmax];     //Pas pour l'interpolation,
  float     Gstop[Nmax];  //Cible pour l'interpolation,

  float     G0[Nmax];     //gains des hp pour la position centrale,
  float     L[Nmax][2][2];//Tableaux contenant toute les matrices
                          //invers�es des configurations de 2 haut-parleurs,
  int       rev[Nmax];    //Tableau qui permet d'ordonner les hp 
                          //par ordre croissant des angles, 

  float     *cosin;       //Adresse des tableaux pour les cosinus,
	int     connected[3]; //inlets connect�s?
} t_vbapan_tilde;


/**********************************************************************/
/*      Prototypage des fonctions et m�thodes.     	                  */
/**********************************************************************/

void  vbapan_tilde_dsp(t_vbapan_tilde *x, t_signal **sp, short *count);
t_int *vbapan_tilde_perform_signal(t_int *w);
void  vbapan_tilde_dsp64(t_vbapan_tilde *x, t_object *dsp64, short *count, double samplerate, long maxvectorsize, long flags);
void  vbapan_tilde_perform_signal64(t_vbapan_tilde *x, t_object *dsp64, double **ins, long numins, double **outs, long numouts, long sampleframes, long flags, void *userparam);
float vbapan_tilde_modulo( float anglep );
void  vbapan_tilde_recoit_x(t_vbapan_tilde *x, double xp);
void  vbapan_tilde_recoit_y(t_vbapan_tilde *x, double yp);
void  vbapan_tilde_recoit_liste( t_vbapan_tilde *x, t_symbol *s, int argc, t_atom *argv);
void  vbapan_tilde_initialiser_nb_hp( t_vbapan_tilde *x, long N);
void  vbapan_tilde_dist_teta_positionner_hp( t_vbapan_tilde *x, t_symbol *s, int argc, t_atom *argv );
void  vbapan_tilde_teta_positionner_hp( t_vbapan_tilde *x, t_symbol *s, int argc, t_atom *argv );
void  vbapan_tilde_xy_positionner_hp( t_vbapan_tilde *x, t_symbol *s, int argc, t_atom *argv );
void  vbapan_tilde_changer_type_repere(t_vbapan_tilde *x, t_symbol *sym);
void  vbapan_tilde_init_hp_mat(t_vbapan_tilde *x );
void  vbapan_tilde_changer_rayon_disq_centrale( t_vbapan_tilde *x, double val);
void  vbapan_tilde_muter_entrees_signal(t_vbapan_tilde *x, int mute);
void  vbapan_tilde_informations( t_vbapan_tilde *x );
void  vbapan_tilde_dest(t_vbapan_tilde *x);
void  *vbapan_tilde_new(t_symbol *s, int argc, Atom *argv );
void  ambipan_tilde_assist(t_vbapan_tilde *x, void *b, long m, long a, char *s);
void  ambipan_tilde_recoit_float(t_vbapan_tilde *x, double data);


/**********************************************************************/
/*      TRAITEMENT DU SIGNAL avec coordonn�es recues en signal.       */
/**********************************************************************/

t_int *vbapan_tilde_perform_signal(t_int *w)
{
  /*Pr�paration des pointeurs****************************************/
  t_vbapan_tilde *x = (t_vbapan_tilde *)(w[1]);//adresse de la dataspace
  float     *son_in   = (t_float *)(w[2]);       //son en entr�e
  float     *xp       = (t_float *)(w[3]);       //r�ception de x
  float     *yp       = (t_float *)(w[4]);       //r�ception de y
  int       n         = (int)(w[5+x->Nout]);     //taille des blocs

  /*D�clarations des variables locales*/
  int   phii;           //angle en entier (de 0 � T_COS),
  float son;            //variable temporaire,
  int   hp;             //indice relatif au haut-parleur,
  int   i;              //indice du n� de l'�chantillon,
  int   N = x->N;       //nombre de haut-parleurs,
  int   retour = x->Nout + 6; //retour pour pure data,
  float xl, yl, xtemp;  //coordonn�ees cart�sienne de la source,
  float g[Nmax];        //gains des haut-parleurs (en signal),
  float phi;            //angle de la source,
  float r;              //rayon de la source.
  float Puis, iAmp;     //puissance et amplitude des gains.
  
  
  /*Pr�paration des pointeurs des sorties ***************************/
  float *out[Nmax];
  for( hp = 0; hp < x->Nout; hp++)
    out[hp] = (t_float *)(w[hp+5]);
	
	
	/******************************************************************/
	/*  zero  **************************************************/
	
	if (x->x_obj.z_disabled) goto noProcess;
	if (!x->connected[0]) {
		for( i=0; i<n; i++) for( hp = 0; hp < x->Nout; hp++) out[hp][i] = 0;/**/
		goto noProcess;
	}

  /******************************************************************/
  /*  Traitements  **************************************************/
	
	if (x->connected[1]) x->c1 = xp[n-1];
	if (x->connected[2]) x->c2 = yp[n-1];

  /******************************************************************/
  /*Si entrees signal mut�es, on utilise le tableau P de contr�le.***/
  if(x->mute || (!x->connected[1] && !x->connected[2])) 
    for( i=0; i<n; i++)
    {
      //on stocke l'�chantillon d'entr�e dans une variable temporaire
      //car son_in = out[0].
      son = son_in[i];


      //Modulation des sorties avec les gains Pn.
      for( hp=N-1; hp >= 0; hp--)
      {
        //Incr�mentation des gains pour l'interpolation,
        if( x->G[hp] == x->Gstop[hp] ) /*rien*/  ;
        else if ( fabs(x->Gstop[hp] - x->G[hp]) > fabs(x->dG[hp]) )
          x->G[hp] += x->dG[hp];
        else
          x->G[hp] = x->Gstop[hp];

        /******************************/
        out[hp][i] = son * x->G[hp];/**/
        /******************************/
      }
    }
  
  /******************************************************************/
  /*Si entr�es signal non mut�es, on utilise les vecteurs de signal**/
  else 
    for( i=n-1; i>=0; i--)
    {
      son = son_in[i];    //On stocke les �chantillons d'entr�e, dans des
      //xl = xp[i];         //variables, car elles vont �tre �cras�es.
      //yl = yp[i];
	   
	   xl = x->connected[1] ? x->c1 = xp[i] : x->c1;
	   yl = x->connected[2] ? x->c2 = yp[i] : x->c2;
  
      /*Conversion polaires -> cart�siennes,*******/
      if( !x->base )
      {
        phi = vbapan_tilde_modulo(yl)*Pi/180;
        r = xl;
        
        //ici xl = rayon et yl = angle,
        phii = (int)( yl*T_COS*I360 )&(int)MASQUE; 
        xtemp    = xl*x->cosin[ phii ];
        phii = (int)(.25*T_COS - phii)&(int)MASQUE;
        yl       = xl*x->cosin[ phii ];
        xl = xtemp;
        //maintenant xl = abscisse et yl = ordonn�e.
        
        //Si r est n�gatif on modifie les coordonn�es,
        if( r<0 ){
          r = -r;
          phi = (phi<Pi)?(phi+Pi):(phi-Pi);
        }
    
      }
      /*Conversion cart�sienne -> polaire,**********/
      else
      {
        r = sqrt( xl*xl+yl*yl );
        phi = acos( xl/r );
        if( yl < 0 )
          phi = 2*Pi - phi;
      }


      //remise � z�ro des gains:
      for( hp=0; hp<x->N; hp++)
        g[hp] = 0;
 
      //Recherche des hp encadrant le point:
      for( hp=0; hp<x->N-1; hp++){
        if( phi >= x->teta[x->rev[hp]] && phi < x->teta[x->rev[hp+1]] )
          break;
      }

      //Calcul du gain:
      g[x->rev[hp]]          = x->L[hp][0][0]*xl + x->L[hp][0][1]*yl;
      g[x->rev[(hp+1)%x->N]] = x->L[hp][1][0]*xl + x->L[hp][1][1]*yl; 
    
      //Puissance du gain (source et hp sur le cercle) :
      Puis =    ( g[x->rev[hp         ]]*g[x->rev[hp         ]] ) 
              + ( g[x->rev[(hp+1)%x->N]]*g[x->rev[(hp+1)%x->N]] );
      iAmp = (Puis <= EPSILON) ? 0 : (1/(float)sqrt(2*Puis));


      if( r > x->r_c )
      {
        //Normalisation des g, et prise en compte des distances :
        g[x->rev[hp]]            *=  iAmp * x->dst_hp[x->rev[ hp        ]] / r;
        g[x->rev[(hp+1)%x->N]]   *=  iAmp * x->dst_hp[x->rev[(hp+1)%x->N]] / r;
      }
      else
      {
        //Calcul du gain (sur le disque central):
        g[x->rev[hp]]            *=  iAmp * x->dst_hp[x->rev[ hp        ]] * r/(x->r_c*x->r_c);
        g[x->rev[(hp+1)%x->N]]   *=  iAmp * x->dst_hp[x->rev[(hp+1)%x->N]] * r/(x->r_c*x->r_c);
        //ici le gain est proportionnelle � r/r_c dans le disque.
        
        //On mixe lin�airement l'effet VBAP avec les gains pour la position centrale:
        for( hp=0; hp<x->N; hp++)
          g[hp] += (1 - r/x->r_c) * x->G0[hp];
      }
      
      for( hp=N-1; hp >= 0 ; hp--)
      {
        /***************************/
        out[hp][i] = son * g[hp];/**/
        /***************************/
      }
    }


  /*Initialisation � z�ro des sorties inutilis�es*/
  for( hp = x->Nout-1 ; hp >= N ; hp--){
    for( i=n-1 ; i>=0; i--)
      out[hp][i] = 0;
  }

noProcess:
  return ( w+retour );
}

//----------------------------------------------------------------------------------------------

void  vbapan_tilde_perform_signal64(t_vbapan_tilde *x, t_object *dsp64, double **ins, long numins, double **outs, long numouts, long sampleframes, long flags, void *userparam)
{
	/*Pr�paration des pointeurs****************************************/
	t_double     *son_in   = ins[0];       //son en entr�e
	t_double     *xp       = ins[1];       //r�ception de x
	t_double     *yp       = ins[2];       //r�ception de y
	int          n         = sampleframes; //taille des blocs
	
	/*D�clarations des variables locales*/
	int   phii;              //angle en entier (de 0 � T_COS),
	t_double son;            //variable temporaire,
	int   hp;                //indice relatif au haut-parleur,
	int   i;                 //indice du n� de l'�chantillon,
	int   N = x->N;          //nombre de haut-parleurs,
	t_double xl, yl, xtemp;  //coordonn�ees cart�sienne de la source,
	t_double g[Nmax];        //gains des haut-parleurs (en signal),
	t_double phi;            //angle de la source,
	t_double r;              //rayon de la source.
	t_double Puis, iAmp;     //puissance et amplitude des gains.
	
	
	/*Pr�paration des pointeurs des sorties ***************************/
	t_double *out[Nmax];
	for( hp = 0; hp < x->Nout; hp++)
		out[hp] = outs[hp];
	
	
	/******************************************************************/
	/*  zero  **************************************************/
	
	if (x->x_obj.z_disabled) goto noProcess;
	if (!x->connected[0]) {
		for( i=0; i<n; i++) for( hp = 0; hp < x->Nout; hp++) out[hp][i] = 0;/**/
		goto noProcess;
	}
	
	/******************************************************************/
	/*  Traitements  **************************************************/
	
	if (x->connected[1]) x->c1 = xp[n-1];
	if (x->connected[2]) x->c2 = yp[n-1];
	
	/******************************************************************/
	/*Si entrees signal mut�es, on utilise le tableau P de contr�le.***/
	if(x->mute || (!x->connected[1] && !x->connected[2])) 
		for( i=0; i<n; i++)
		 {
			//on stocke l'�chantillon d'entr�e dans une variable temporaire
			//car son_in = out[0].
			son = son_in[i];
			
			
			//Modulation des sorties avec les gains Pn.
			for( hp=N-1; hp >= 0; hp--)
			 {
				//Incr�mentation des gains pour l'interpolation,
				if( x->G[hp] == x->Gstop[hp] ) /*rien*/  ;
				else if ( fabs(x->Gstop[hp] - x->G[hp]) > fabs(x->dG[hp]) )
					x->G[hp] += x->dG[hp];
				else
					x->G[hp] = x->Gstop[hp];
				
				/******************************/
				out[hp][i] = son * x->G[hp];/**/
				/******************************/
			 }
		 }
	
	/******************************************************************/
	/*Si entr�es signal non mut�es, on utilise les vecteurs de signal**/
	else 
		for( i=n-1; i>=0; i--)
		 {
			son = son_in[i];    //On stocke les �chantillons d'entr�e, dans des
			//xl = xp[i];         //variables, car elles vont �tre �cras�es.
			//yl = yp[i];
			
			xl = x->connected[1] ? x->c1 = xp[i] : x->c1;
			yl = x->connected[2] ? x->c2 = yp[i] : x->c2;
			
			/*Conversion polaires -> cart�siennes,*******/
			if( !x->base )
			 {
				phi = vbapan_tilde_modulo(yl)*Pi/180;
				r = xl;
				
				//ici xl = rayon et yl = angle,
				phii = (int)( yl*T_COS*I360 )&(int)MASQUE; 
				xtemp    = xl*x->cosin[ phii ];
				phii = (int)(.25*T_COS - phii)&(int)MASQUE;
				yl       = xl*x->cosin[ phii ];
				xl = xtemp;
				//maintenant xl = abscisse et yl = ordonn�e.
				
				//Si r est n�gatif on modifie les coordonn�es,
				if( r<0 ){
					r = -r;
					phi = (phi<Pi)?(phi+Pi):(phi-Pi);
				}
				
			 }
			/*Conversion cart�sienne -> polaire,**********/
			else
			 {
				r = sqrt( xl*xl+yl*yl );
				phi = acos( xl/r );
				if( yl < 0 )
					phi = 2*Pi - phi;
			 }
			
			
			//remise � z�ro des gains:
			for( hp=0; hp<x->N; hp++)
				g[hp] = 0;
			
			//Recherche des hp encadrant le point:
			for( hp=0; hp<x->N-1; hp++){
				if( phi >= x->teta[x->rev[hp]] && phi < x->teta[x->rev[hp+1]] )
					break;
			}
			
			//Calcul du gain:
			g[x->rev[hp]]          = x->L[hp][0][0]*xl + x->L[hp][0][1]*yl;
			g[x->rev[(hp+1)%x->N]] = x->L[hp][1][0]*xl + x->L[hp][1][1]*yl; 
			
			//Puissance du gain (source et hp sur le cercle) :
			Puis =    ( g[x->rev[hp         ]]*g[x->rev[hp         ]] ) 
			+ ( g[x->rev[(hp+1)%x->N]]*g[x->rev[(hp+1)%x->N]] );
			iAmp = (Puis <= EPSILON) ? 0 : (1/(t_double)sqrt(2*Puis));
			
			
			if( r > x->r_c )
			 {
				//Normalisation des g, et prise en compte des distances :
				g[x->rev[hp]]            *=  iAmp * x->dst_hp[x->rev[ hp        ]] / r;
				g[x->rev[(hp+1)%x->N]]   *=  iAmp * x->dst_hp[x->rev[(hp+1)%x->N]] / r;
			 }
			else
			 {
				//Calcul du gain (sur le disque central):
				g[x->rev[hp]]            *=  iAmp * x->dst_hp[x->rev[ hp        ]] * r/(x->r_c*x->r_c);
				g[x->rev[(hp+1)%x->N]]   *=  iAmp * x->dst_hp[x->rev[(hp+1)%x->N]] * r/(x->r_c*x->r_c);
				//ici le gain est proportionnelle � r/r_c dans le disque.
				
				//On mixe lin�airement l'effet VBAP avec les gains pour la position centrale:
				for( hp=0; hp<x->N; hp++)
					g[hp] += (1 - r/x->r_c) * x->G0[hp];
			 }
			
			for( hp=N-1; hp >= 0 ; hp--)
			 {
				/***************************/
				out[hp][i] = son * g[hp];/**/
				/***************************/
			 }
		 }
	
	
	/*Initialisation � z�ro des sorties inutilis�es*/
	for( hp = x->Nout-1 ; hp >= N ; hp--){
		for( i=n-1 ; i>=0; i--)
			out[hp][i] = 0;
	}
	
noProcess:
	return;
}

/**********************************************************************/
/*        METHODE RECOIT_float                                        */
/**********************************************************************/

void  vbapan_tilde_recoit_float(t_vbapan_tilde *x, double data)
{
	int inlet = proxy_getinlet((t_object *)x);
	switch (inlet) {
		case 1:
			if (!x->connected[1]) x->c1 = data;
			vbapan_tilde_recoit_x(x, data);
			break;
		case 2:
			if (!x->connected[2]) x->c2 = data;
			vbapan_tilde_recoit_y(x, data);
			break;
		default:
			break;
	}
}

/**********************************************************************/
/*        METHODE RECOIT_x                                            */
/**********************************************************************/
//Cette m�thode re�oit x et change tous les gains : 

void vbapan_tilde_recoit_x(t_vbapan_tilde *x, double xp)
{
  float Puis, iAmp;
  int   hp;
  float yp  = x->y;
  float phi = x->phi;
  float r;

  //Conversion polaires -> cart�siennes,
  if( !x->base )
  {
    //ici xp = rayon,
    r  = xp;
    xp = (float)( r * cos( phi ) );
    yp = (float)( r * sin( phi ) );
    //maintenant xp = abscisse.  
  }
  //Conversion cart�sienne -> polaire,
  else
  {
    r = sqrt( xp*xp+yp*yp );
    phi = acos( xp/r );
    if( yp < 0 )
      phi = 2*Pi - phi;   
  }  
  x->r   = r; 
  x->phi = phi;
  x->y   = yp;
  x->x   = xp;
  
  //Si r est n�gatif on modifie les coordonn�es mais pas la dataspace,
  if( r<0 )
  {
    r = -r;
    phi = (phi<Pi)?(phi+Pi):(phi-Pi);
  }
  
  //Remise � z�ro de tout les gains cibles:
  for(hp=0; hp<x->Nout; hp++)
    x->Gstop[hp] = 0;
    
 
  //Recherche des hp encadrant le point:
  for( hp=0; hp<x->N-1; hp++){
    if( phi >= x->teta[x->rev[hp]] && phi < x->teta[x->rev[hp+1]] ) 
      break;
  }


  //Calcul des gains :
  x->Gstop[x->rev[hp]]          = x->L[hp][0][0]*xp + x->L[hp][0][1]*yp;
  x->Gstop[x->rev[(hp+1)%x->N]] = x->L[hp][1][0]*xp + x->L[hp][1][1]*yp;

  //Puissance du gain (source et hp sur le cercle) :
  Puis =    ( x->Gstop[x->rev[hp         ]]*x->Gstop[x->rev[hp         ]] ) 
          + ( x->Gstop[x->rev[(hp+1)%x->N]]*x->Gstop[x->rev[(hp+1)%x->N]] );
  iAmp = (Puis <= EPSILON) ? 0 : (1/(float)sqrt(2*Puis));


  if( r > x->r_c )
  {
    //Normalisation des g, et prise en compte des distances :
    x->Gstop[x->rev[hp]]           *=  iAmp * x->dst_hp[x->rev[ hp        ]] / r;
    x->Gstop[x->rev[(hp+1)%x->N]]  *=  iAmp * x->dst_hp[x->rev[(hp+1)%x->N]] / r;
  }
  else
  {
    //Calcul du gain (sur le disque central):
    x->Gstop[x->rev[hp]]           *=  iAmp * x->dst_hp[x->rev[ hp        ]] * r/(x->r_c*x->r_c);
    x->Gstop[x->rev[(hp+1)%x->N]]  *=  iAmp * x->dst_hp[x->rev[(hp+1)%x->N]] * r/(x->r_c*x->r_c);
    //ici le gain est proportionnelle � r/r_c dans le disque.
    
    //On mixe lin�airement l'effet VBAP avec les gains pour la position centrale:
    for( hp=0; hp<x->N; hp++)
      x->Gstop[hp] += (1 - r/x->r_c) * x->G0[hp];
  }
  
  // Interpolation :
  for( hp=0; hp<x->N; hp++)
  {
    x->dG[hp]          = ( x->Gstop[hp]          - x->G[hp]          ) /(float)x->dtime;
    x->dG[(hp+1)%x->N] = ( x->Gstop[(hp+1)%x->N] - x->G[(hp+1)%x->N] ) /(float)x->dtime;
  }

  return;
}



/**********************************************************************/
/*        METHODE RECOIT_y                                            */
/**********************************************************************/
//Cette m�thode re�oit y et change tous les param�tres :

void vbapan_tilde_recoit_y(t_vbapan_tilde *x, double yp)
{
  float Puis, iAmp;
  int hp;
  float xp = x->x;
  float r  = x->r;
  float phi;
  
  //Conversion polaire -> cart�sienne,
  if( !x->base )
  {
    //ici yp = angle,
    phi = (float)(vbapan_tilde_modulo(yp)*Pi/180.);
    xp  = (float)( r * cos( phi ) );
    yp  = (float)( r * sin( phi ) );
    //maintenant yp = ordonn�e,
  }
  //Conversion cart�sienne -> polaire,
  else
  {
    r = sqrt( xp*xp+yp*yp );
    phi = acos( xp/r );
    if( yp < 0 )
      phi = 2*Pi - phi;   
  }    
  x->y = yp;
  x->x = xp;
  x->r = r;
  x->phi = phi;

  //Si r est n�gatif on modifie les coordonn�es mais pas la dataspace,
  if( r<0 )
  {
    r = -r;
    phi = (phi<Pi)?(phi+Pi):(phi-Pi);
  }
  
  //Remise � z�ro de tout les gains cibles:
  for(hp=0; hp<x->Nout; hp++)
    x->Gstop[hp] = 0;
 

  //Recherche des hp encadrant le point:
  for( hp=0; hp<x->N-1; hp++){
    if( phi >= x->teta[x->rev[hp]] && phi < x->teta[x->rev[hp+1]] )
      break;
  }


  //Calcul des gains :
  x->Gstop[x->rev[hp]]          = x->L[hp][0][0]*xp + x->L[hp][0][1]*yp;
  x->Gstop[x->rev[(hp+1)%x->N]] = x->L[hp][1][0]*xp + x->L[hp][1][1]*yp;

  //Puissance du gain (source et hp sur le cercle) :
  Puis =    ( x->Gstop[x->rev[hp         ]]*x->Gstop[x->rev[hp         ]] ) 
          + ( x->Gstop[x->rev[(hp+1)%x->N]]*x->Gstop[x->rev[(hp+1)%x->N]] );
  iAmp = (Puis <= EPSILON) ? 0 : (1/(float)sqrt(2*Puis));


  if( r > x->r_c )
  {
    //Normalisation des g, et prise en compte des distances :
    x->Gstop[x->rev[hp]]           *=  iAmp * x->dst_hp[x->rev[ hp        ]] / r;
    x->Gstop[x->rev[(hp+1)%x->N]]  *=  iAmp * x->dst_hp[x->rev[(hp+1)%x->N]] / r;
  } 
  else
  {
    //Calcul du gain (sur le disque central):
    x->Gstop[x->rev[hp]]           *=  iAmp * x->dst_hp[x->rev[ hp        ]] * r/(x->r_c*x->r_c);
    x->Gstop[x->rev[(hp+1)%x->N]]  *=  iAmp * x->dst_hp[x->rev[(hp+1)%x->N]] * r/(x->r_c*x->r_c);
    //ici le gain est proportionnelle � r/r_c dans le disque.
    
    //On mixe lin�airement l'effet VBAP avec les gains pour la position centrale:
    for( hp=0; hp<x->N; hp++)
      x->Gstop[hp] += (1 - r/x->r_c) * x->G0[hp];
  }
  
  // Interpolation :
  for( hp=0; hp<x->N; hp++)
  {
    x->dG[hp]          = ( x->Gstop[hp]          - x->G[hp]          ) /(float)x->dtime;
    x->dG[(hp+1)%x->N] = ( x->Gstop[(hp+1)%x->N] - x->G[(hp+1)%x->N] ) /(float)x->dtime;
  }

  return;
}



/**********************************************************************/
/*        METHODE RECOIT_LISTE                                        */
/**********************************************************************/

void vbapan_tilde_recoit_liste( t_vbapan_tilde *x, t_symbol *s, int argc, t_atom *argv)
{
  float xp = 0, yp = 0;
  
  //R�cup�ration du premier param�tre (abscisse ou rayon),
  if( argv[0].a_type == A_FLOAT )
    xp = argv[0].a_w.w_float;
  else if( argv[0].a_type == A_LONG )
    xp = (float)(argv[0].a_w.w_long);
    
  //R�cup�ration du second param�tre (ordonn�e ou angle),
  if( argc >= 2 )
  {
    if( argv[1].a_type == A_FLOAT )
      yp = argv[1].a_w.w_float;
    else if( argv[1].a_type == A_LONG )
      yp = (float)(argv[1].a_w.w_long);
  } 
  else if( x->base )
    yp = x->y;
  else 
    yp = x->phi*180/Pi;
  
  //Initialisation des valeurs,
  if( x->base )    x->y = yp;
  else             x->phi = vbapan_tilde_modulo(yp)*Pi/180;

  vbapan_tilde_recoit_x( x, xp);

  return;
}



/**********************************************************************/
/*      METHODE POSITIONNER HAUT-PARLEUR sur le cercle avec phi       */
/**********************************************************************/

void vbapan_tilde_teta_positionner_hp( t_vbapan_tilde *x, t_symbol *s, int argc, t_atom *argv )
{
  int hp;

  for( hp=0; hp<x->N && hp<argc; hp++)
  {
    //R�cup�ration des angles.
    if( argv[hp].a_type == A_FLOAT )
      x->teta[hp] = (vbapan_tilde_modulo(argv[hp].a_w.w_float)*Pi/180.);
    else if( argv[hp].a_type == A_LONG )
      x->teta[hp] = (vbapan_tilde_modulo((float)argv[hp].a_w.w_long)*Pi/180.);
    else if( argv[hp].a_type == A_SYM ){
      object_error((t_object *)x, "les membres de la liste doivent etre des nombres.");
      return;
    }

    //Affectations des nouvelles coordonn�es:
    x->x_hp[hp] = cos( x->teta[hp] );
    x->y_hp[hp] = sin( x->teta[hp] );

    //La distance sera initialis�e dans "init_hp_mat()".
  }
  
  //Modification des matrices relatives aux hp:
  vbapan_tilde_init_hp_mat( x );
  
  /*Affectation des gains des hp*/
	if(x->base)     vbapan_tilde_recoit_x( x, x->x);
    else            vbapan_tilde_recoit_x( x, x->r);

  return;
}



/**********************************************************************/
/*      METHODE POSITIONNER HAUT-PARLEUR  avec phi et le rayon        */
/**********************************************************************/

void vbapan_tilde_dist_teta_positionner_hp( t_vbapan_tilde *x, t_symbol *s, int argc, t_atom *argv )
{
  int hp;
  float rayon;

  for( hp=0; hp<x->N && 2*hp<argc; hp++)
  {
    //R�cup�ration des distances des haut-praleurs au centre,
    if( argv[2*hp].a_type == A_FLOAT )
      rayon = (argv[2*hp].a_w.w_float);
    else if( argv[2*hp].a_type == A_LONG )
      rayon = (float)(argv[2*hp].a_w.w_long);
    else if( argv[2*hp].a_type == A_SYM ){
      object_error((t_object *)x, "les membres de la liste doivent etre des nombres.");
      return;
    }

    //R�cup�ration des angles des hp,
    if( 2*hp+1<argc )
    {
      if( argv[2*hp+1].a_type == A_FLOAT )
        x->teta[hp] = (vbapan_tilde_modulo(argv[2*hp+1].a_w.w_float)*Pi/180);
      else if( argv[2*hp+1].a_type == A_LONG )
        x->teta[hp] = (vbapan_tilde_modulo((float)argv[2*hp+1].a_w.w_long)*Pi/180);
      else if( argv[2*hp+1].a_type == A_SYM ){
        object_error((t_object *)x, "les membres de la liste doivent etre des nombres.");
        return;
      }
    }
   
    //Affectations des nouvelles coordonn�es:
    x->x_hp[hp] = rayon*cos( x->teta[hp] );
    x->y_hp[hp] = rayon*sin( x->teta[hp] );
  }

  //Modification des matrices relatives aux hp:
  vbapan_tilde_init_hp_mat( x );


  /*Affectation des gains des hp*/
  if(x->base)     vbapan_tilde_recoit_x( x, x->x);
  else            vbapan_tilde_recoit_x( x, x->r);

  return;
}


/**********************************************************************/
/*      METHODE POSITIONNER HAUT-PARLEUR  avec coordonn�es x et y     */
/**********************************************************************/

void vbapan_tilde_xy_positionner_hp( t_vbapan_tilde *x, t_symbol *s, int argc, t_atom *argv )
{
  int hp;
  float xp, yp = 0,
        rayon, angle;

  /*R�cup�ration des coordonn�es cart�siennes**********/
  for( hp=0; hp<x->N && 2*hp<argc; hp++)
  {
    if( argv[2*hp].a_type == A_FLOAT )
      xp = (argv[2*hp].a_w.w_float);
    else if( argv[2*hp].a_type == A_LONG )
      xp = (float)(argv[2*hp].a_w.w_long);
    else if( argv[2*hp].a_type == A_SYM ){
      object_error((t_object *)x, "les membres de la liste doivent �tre des nombres.");
      return;
    }

    if( 2*hp+1<argc )
    {
      if( argv[2*hp+1].a_type == A_FLOAT )
        yp = (argv[2*hp+1].a_w.w_float);
      else if( argv[2*hp+1].a_type == A_LONG )
        yp = (float)(argv[2*hp+1].a_w.w_long);
      else if( argv[2*hp+1].a_type == A_SYM ){
        object_error((t_object *)x, "les membres de la liste doivent etre des nombres.");
        return;
      }
    }
    else
      yp = x->y_hp[hp];


    /*Conversion en polaires****************************/  
    rayon = (float)sqrt( pow( xp, 2) + pow( yp, 2) );
    if( rayon!=0 )
    {
      angle = (float)acos( (float)xp/rayon );
      if(yp<0)
        angle = 2*Pi - angle;
    }
    else
      angle = 0;

    //Affectation des nouvelles coordonn�es:
    x->teta[hp] = angle;
    x->x_hp[hp] = xp;
    x->y_hp[hp] = yp;
  }

  //Modification des matrices relatives aux hp:
  vbapan_tilde_init_hp_mat( x );
    
  /*Affectation des gains des hp*/
  if(x->base)     vbapan_tilde_recoit_x( x, x->x);
  else            vbapan_tilde_recoit_x( x, x->r);
    
  return;
}





/**********************************************************************/
/*              METHODE MODIFIER LE NOMBRE DE HP                      */
/**********************************************************************/

void vbapan_tilde_initialiser_nb_hp( t_vbapan_tilde *x, long N)
{
  int hp;


  if( x->Nout >= N && 2 < N )
  {
    x->N = (int)N;
    
    //Modifications des angles des haut-parleurs et des rayons,
    for( hp=0; hp<x->N; hp++){
      x->teta[hp] = (float)( Pi*( .5 + (1 - 2*hp )/(float)x->N) );
      if( x->teta[hp] < 0)
        x->teta[hp] += 2*Pi;
      x->x_hp[hp] = cos( x->teta[hp] );
      x->y_hp[hp] = sin( x->teta[hp] );
    }

    //Modification des matrices relatives aux hp:
    vbapan_tilde_init_hp_mat( x );
  }  
  else
    object_error((t_object *)x, "Le nombre de haut-parleurs doit �tre "
                   "inf�rieur � %d, \n"
                   "  et sup�rieur � 3, ou �gal.", x->Nout);
    
  /*Affectation des gains */
  if(x->base)     vbapan_tilde_recoit_x( x, x->x);
  else            vbapan_tilde_recoit_x( x, x->r);
   
}



/**********************************************************************/
/*              METHODE POUR MUTER LES ENTREES SIGNAL                 */
/**********************************************************************/

void  vbapan_tilde_muter_entrees_signal(t_vbapan_tilde *x, int mute)
{
  if( mute == 0)   x->mute = 0;
  else             x->mute = 1;
}



/**********************************************************************/
/*                   MODIFICATION DU TYPE DE REPERE                   */
/**********************************************************************/

void vbapan_tilde_changer_type_repere(t_vbapan_tilde *x, t_symbol *sym)
{
  //Changement de x->base
  if( sym->s_name[0] == 'c')
    x->base = 1;
  else if( sym->s_name[0] == 'p')
    x->base = 0; 
  else 
    object_error((t_object *)x, "type de repere inconnu.");
    
  //Si coordonn�es polaires il faut initialiser x->r et x->phi:
  if( x->base == 0 )    //(Inutile en fait).
  {
    //Conversion de x et y en polaires:  
    x->r = (float)sqrt( pow( x->x, 2) + pow( x->y, 2) );
    if( x->r!=0 )
    {
      x->phi = (float)acos( (float)x->x/x->r );
      if(x->y<0)
        x->phi = 2*Pi - x->phi;
    }
    else
      x->phi = 0;
  }  
}




/**********************************************************************/
/*            METHODE CHANGER RAYON DU DISQUE CENTRAL                 */
/**********************************************************************/

void vbapan_tilde_changer_rayon_disq_centrale(t_vbapan_tilde *x, double val)
{    
  if(val <= EPSILON ){
    object_error((t_object *)x, "pas de rayon nul ou negatif.");
    return;
  }
  x->r_c = val;

  //Modification des matrices relatives aux hp:
  vbapan_tilde_init_hp_mat( x );
    
  /*Affectation des gains des hp*/
  if(x->base)     vbapan_tilde_recoit_x( x, x->x);
  else            vbapan_tilde_recoit_x( x, x->r);

  return;
}



/**********************************************************************/
/*         AFFICHAGE DES INFORMATIONS DANS LA FENETRE DE MAX          */
/**********************************************************************/

void vbapan_tilde_informations( t_vbapan_tilde *x)
{
  int hp;
  
  object_post((t_object *)x, "Info Vbapan~: ");
  
	if(x->base) post("   coordonnees cartesiennes,");
	else post("   coordonnees polaires,");
    
	if(!x->mute)	post("   avec entrees signal actives,");
	else post("   avec entrees signal inactives,");

  post("   rayon du disque central = %f,", x->r_c);
  post("   temps d'interpolation (pour le controle)  = %d ms,", (int)(x->dtime*1000/sys_getsr()));
  post("   nombre de haut-parleurs = %d," , x->N);
  
  post("   position des haut-parleurs:");
  for( hp=0; hp<x->N-1; hp++)
    post("      hp n�%d: %f.x + %f.y,", hp+1, x->x_hp[hp], x->y_hp[hp] );
    
  post("      hp n�%d: %f.x + %f.y.", hp+1, x->x_hp[hp], x->y_hp[hp] );
	post("      ***");
}
    
//--------------- Assistance Methode ---------------------//

void vbapan_tilde_assist(t_vbapan_tilde *x, void *b, long m, long a, char *s)
{
	if (m == ASSIST_INLET) {
		switch (a) {
			case 0:
				sprintf(s,"(Signal) Mono Source input");
				break;
			case 1:
				if (x->base) sprintf(s,"(Signal/float) Abscissa of the Source");
				else sprintf(s,"(Signal/float) Distance of the Source");
				break;
			case 2:
				if (x->base) sprintf(s,"(Signal/float) Ordinate of the Source");
				else sprintf(s,"(Signal/float) Angle of the Source");
				break;
		}
	}
	else
		sprintf(s,"(Signal) Out %ld", (a+1));
}

/**********************************************************************/
/*                       FONCTION DESTRUCTION                         */
/**********************************************************************/

void vbapan_tilde_dest(t_vbapan_tilde *x)
{
	dsp_free((t_pxobject *)x);
	freebytes( x->cosin, (short)(T_COS*sizeof(float)) ); //Lib�ration de la m�moire allou�e pour les cosinus//
	return;
}


/**********************************************************************/
/*                       FONCTION CREATION                            */
/**********************************************************************/

void *vbapan_tilde_new( t_symbol *s, int argc, t_atom *argv )
{
	int    i, hp, newVersion;
	char   car;
	
	/*Allocation de la dataspace ****************************/
	t_vbapan_tilde *x = object_alloc(vbapan_tilde_class);
	
	/********************************************************/
	/*R�cup�ration du nombre de sorties et de haut-parleurs */
	if( argc >= 1 ){
		if( argv[0].a_type == A_LONG )
			x->N = argv[0].a_w.w_long;
		else x->N = 0;               }
	else 
		x->N = Ndefaut;
	
	if( x->N <= 2 || x->N > Nmax ){
		x->N = Ndefaut;
		object_error((t_object *)x, "Il y a un probleme dans la declaration du nombre de haut-parleur, il est de %d par defaut.", Ndefaut);
	}
	x->Nout = x->N;  //M�me nombre de sorties et d'haut-parleur.
	
	
	/*R�cup�ration du type rep�re ****************************/
	if( argc >=2 ){
		if( argv[1].a_type == A_SYM )
			car = (char)(argv[1].a_w.w_sym->s_name[0]);
		
		if( car == 'c' )
			x->base=1;
		else if( car == 'p' )
			x->base=0;
		else {
			x->base=1;
			object_error((t_object *)x, "erreur dans le type des coordonnees, elles sont cartesiennes par defaut.");
		}
	}
	else 
		x->base = 1;
	
    
	/*R�cup�ration du type des entr�es (pour des questions de compatibilit� avec l'ancienne version) *******************/
	if( argc >=3 && argv[2].a_type == A_SYM){
		object_error((t_object *)x, "l'argument signal/controle est sans effet dans cette version.");
		newVersion = 0;
	} else newVersion = 1;
	
	
	if (!newVersion) { // si ancienne version : arg 4 = offset, arg 5 = interp time :
		/*R�cup�ration du rayon du disque central **************/
		if( argc >= 4 && argv[3].a_type == A_FLOAT )
			x->r_c = fabs(argv[3].a_w.w_float);
		else if( argc >= 4 && argv[3].a_type == A_LONG )
			x->r_c = fabs(argv[3].a_w.w_long);
		else
			x->r_c = (float)Rdisq;
		if( x->r_c <= EPSILON ){
			object_error((t_object *)x, "Pas de rayon de disque centrale nul s'il vous plait.");
			x->r_c = (float)Rdisq;
		}
		
		/*R�cup�ration du temps d'interpolation ******************/
		if( argc >= 5 && argv[4].a_type == A_LONG )
			x->dtime = (int)(argv[4].a_w.w_long*sys_getsr()/1000.);
		else
			x->dtime = (int)(DTIME*sys_getsr()/1000.);
		if( x->dtime <= 0 )
			x->dtime = 1;
	}
	else {
		/*R�cup�ration du rayon du disque central **************/
		if( argc >= 3 && argv[2].a_type == A_FLOAT )
			x->r_c = fabs(argv[2].a_w.w_float);
		else if( argc >= 3 && argv[2].a_type == A_LONG )
			x->r_c = fabs(argv[2].a_w.w_long);
		else
			x->r_c = (float)Rdisq;
		if( x->r_c <= EPSILON ){
			object_error((t_object *)x, "Pas de rayon de disque centrale nul s'il vous plait.");
			x->r_c = (float)Rdisq;
		}
		
		/*R�cup�ration du temps d'interpolation ******************/
		if( argc >= 4 && argv[3].a_type == A_LONG )
			x->dtime = (int)(argv[3].a_w.w_long*sys_getsr()/1000.);
		else
			x->dtime = (int)(DTIME*sys_getsr()/1000.);
		if( x->dtime <= 0 )
			x->dtime = 1;
	}

	/*********************************************************/
	/*Initialisation des donn�es de la classe*****************/
	for( hp = x->N-1; hp >= 0; hp--) //Initialisation des P
		x->G[hp] = 0;
	
	x->mute= 0;             //entr�es signal non mut�es
	x->y   = Ydefaut;       //initialisation de y
	x->phi = Phidefaut;     //initialisation de phi
	
	//Initialisation des angles des haut-parleurs et des rayons,
	for( hp=0; hp<x->N; hp++)
	 {
		x->teta[hp] = (float)( Pi*( .5 + (1 - 2*hp )/(float)x->N) );
		if( x->teta[hp] < 0)
			x->teta[hp] += 2*Pi;
		x->x_hp[hp] = cos( x->teta[hp]);
		x->y_hp[hp] = sin( x->teta[hp]);
	 }
	
	//Initialisation de tout les tableaux relatifs aux hp:
	vbapan_tilde_init_hp_mat( x );
	
	//initialisation de x, X, Y, W et Pn par la m�thode recoit x.
	if( x->base )    vbapan_tilde_recoit_x( x, Xdefaut);
	else             vbapan_tilde_recoit_x( x, Rdefaut);     
	
	
	/*********************************************************/
	/*Cr�ation du tableaux cosinus                           */
	
	x->cosin = (float*)getbytes( (short)(T_COS*sizeof(float)) );
	
	//Remplissage du tableau cosinus,
	for( i=0; i<T_COS; i++)
		x->cosin[i] = (float)cos( i*2*Pi/T_COS );
	
	/*Pour avoir besoin de cos( phi ), on cherche:
	 cos(phi) = 
	 cosin[ (int)( phi*T_COS/360 ))&(((int)T_COS-1) ] */
	
	/*********************************************************/
	/*Cr�ation des nouvelles entr�es. ************************/
	dsp_setup((t_pxobject *)x, 3);
    
	/*Cr�ation des sorties************************************/
	for( i=0; i < x->N; i++) outlet_new((t_object *)x, "signal");
	
	return (void *)x;
}



/**********************************************************************/
/*                    DEFINITION DE LA CLASSE	                        */
/**********************************************************************/

int main(void) 
{
	
	t_class *c = class_new("vbapan~", 
						   (method)vbapan_tilde_new, 
						   (method)vbapan_tilde_dest, 
						   (short)sizeof(t_vbapan_tilde), NULL, A_GIMME, 0);
	
	//-------------D�finition des m�thodes-------------------//
	class_addmethod(c, (method)vbapan_tilde_dsp, "dsp", A_CANT, 0);
	class_addmethod(c, (method)vbapan_tilde_dsp64, "dsp64", A_CANT, 0);
	class_addmethod(c, (method)vbapan_tilde_recoit_liste, "list", A_GIMME, 0);
	class_addmethod(c, (method)vbapan_tilde_recoit_float, "float", A_FLOAT, 0);
	class_addmethod(c, (method)vbapan_tilde_initialiser_nb_hp, "set_nb_hp", A_LONG, 0);
	class_addmethod(c, (method)vbapan_tilde_muter_entrees_signal, "mute_sig", A_LONG, 0);
	class_addmethod(c, (method)vbapan_tilde_changer_type_repere, "change_type", A_SYM, 0);
	class_addmethod(c, (method)vbapan_tilde_teta_positionner_hp, "a_setpos", A_GIMME, 0);
	class_addmethod(c, (method)vbapan_tilde_xy_positionner_hp, "xy_setpos", A_GIMME, 0);
	class_addmethod(c, (method)vbapan_tilde_dist_teta_positionner_hp, "ra_setpos", A_GIMME, 0);
	class_addmethod(c, (method)vbapan_tilde_changer_rayon_disq_centrale, "set_disc", A_FLOAT, 0);
	class_addmethod(c, (method)vbapan_tilde_informations, "get_info", 0);
	class_addmethod(c, (method)vbapan_tilde_assist,"assist",A_CANT,0);
	
	/*Publicit� pour le CICM *********************************/
	post("\"vbapan~\"  Auteurs: R.MIGNOT  "
		 "et B.COURRIBET, CICM Universit� Paris8,");
	post("           MSH Paris Nord, ACI Jeunes "
		 "Chercheurs \"Espaces Sonores\".");
	post("           cicm\100univ-paris8.fr.");
	post("v2.0, Max 6.0.4 version by E.PARIS.");
	
	/*Ajout du nom de l'objet dans liste*/
	finder_addclass( "CICMTOOLS", "ambicube~");
	finder_addclass( "CICMTOOLS", "ambipan~");
	finder_addclass( "CICMTOOLS", "vbapan~");
	finder_addclass( "CICMTOOLS", "six2head~");
	finder_addclass( "CICMTOOLS", "cube2head~");
	
	class_dspinit(c);
	class_register(CLASS_BOX, c);
	vbapan_tilde_class = c;	
	
	return 0;
}




/**********************************************************************/
/*      FONCTION QUI DONNE LE MODULO 360 D'UN ANGLE EN FLOTTANT       */
/**********************************************************************/

float vbapan_tilde_modulo(float anglep)
{
  float angle;

  if( anglep >= 0 && anglep < 360 )    return anglep;

  angle = anglep;
  while( angle < 0 )     angle += 360;
  while( angle >= 360 )  angle -= 360;
    
  return angle;
}



/**********************************************************************/
/*               FONCTION CHANGER LES MATRICES DES HP                 */
/**********************************************************************/

void vbapan_tilde_init_hp_mat(t_vbapan_tilde *x)
{
  float xhp1, yhp1, xhp2, yhp2; //Coordonn�es provisoires des hp,
  int   hp, i, j;               //indices de boucles,
  int   itemp; float ftemp;     //entier et flottant temporaire,
  float g[Nmax];                //gains de la position centrale,
  float Puis, iAmp;             //puissance et amplitude des gains,
  float pteta, pdist;           //angle et distance porovisoires,
  float g1, g2;                 //gains provisoires.
  float px[4]={1,0,-1, 0};      //positions des 4 points pour la position centrale,
  float py[4]={0,1, 0,-1};


  //Initialisation des tableaux:
  for( i=0; i<Nmax; i++)
  {
    x->rev[i] = i;
    g[i] = 0;
  }


  //Arrangement du tableau rev qui donne l'ordre croissant des angles des hp:
  // ordre croissant -> ordre de cr�ation.
  for( j=0; j<x->N; j++ ) {
    for( i=0; i<x->N-1; i++ ) {
      if( x->teta[x->rev[i]] > x->teta[x->rev[i+1]] )
      {
        itemp = x->rev[i];
        x->rev[i] = x->rev[i+1];
        x->rev[i+1] = itemp;
      }
    }
  }
  

  //Calcul des distances des haut-parleurs:
  for( hp=0; hp<x->N; hp++)
    x->dst_hp[hp] = (float)sqrt( x->x_hp[hp]*x->x_hp[hp] + x->y_hp[hp]*x->y_hp[hp] );


  //Calcul des matrices invers�es, dans l'ordre des t�ta croissants :
  for( hp=0; hp<x->N; hp++)
  {

    // Coodonn�es des hp ramen�s sur le cercle
    xhp1 = x->x_hp[ x->rev[hp]          ] / x->dst_hp[x->rev[hp]];
    yhp1 = x->y_hp[ x->rev[hp]          ] / x->dst_hp[x->rev[hp]];
    xhp2 = x->x_hp[ x->rev[(hp+1)%x->N] ] / x->dst_hp[x->rev[(hp+1)%x->N]];
    yhp2 = x->y_hp[ x->rev[(hp+1)%x->N] ] / x->dst_hp[x->rev[(hp+1)%x->N]];


    // Calcul du d�nominateur
    ftemp = xhp1 * yhp2 - yhp1 * xhp2;

    // Si le d�nominateur est nul, c'est que 2 hp cons�cutifs 
    //sont align�s, c'est pas possible.
    if( fabs( ftemp ) <= EPSILON )    {
      object_error((t_object *)x, "deux haut-parleurs adjacents sont alignes, \n"
            "  la configuration actuelle n'est pas possible.");
      ftemp = 0;
    }
    else
      ftemp = 1/ftemp;


    // Calcul de la matrice inverse associ�e aux 2 hp:
    x->L[hp][0][0] =  ftemp*yhp2;
    x->L[hp][0][1] = -ftemp*xhp2;
    x->L[hp][1][0] = -ftemp*yhp1;
    x->L[hp][1][1] =  ftemp*xhp1;
  }



  
  //Boucle sur les quatres points pour calculer les gains de la position centrale.
  for( i = 0; i < 4; i++ )
  {
      pdist = (float)sqrt( px[i]*px[i] + py[i]*py[i] );
  
      pteta = (float)acos( px[i]/pdist );
      if( py[i] < 0 )
        pteta = 2*Pi - pteta;
 
      //Recherche des hp encadrant le point:
      for( hp=0; hp<x->N-1; hp++){
        if( pteta >= x->teta[x->rev[hp]] && pteta < x->teta[x->rev[(hp+1)%x->N]] )
          break;
      }

      //Calcul des gains:
      g1 = x->L[hp][0][0]*px[i] + x->L[hp][0][1]*py[i];
      g2 = x->L[hp][1][0]*px[i] + x->L[hp][1][1]*py[i];

      //Calcul de l'amplitude efficace:
      Puis =  g1*g1 + g2*g2;
      iAmp = (Puis <= EPSILON) ? 0 : (1/(float)sqrt(2*Puis));

      //Normalisation des g, et prise en compte des distances:
      g[x->rev[hp]]           +=  g1 * iAmp * x->dst_hp[x->rev[ hp        ]] /pdist;
      g[x->rev[(hp+1)%x->N]]  +=  g2 * iAmp * x->dst_hp[x->rev[(hp+1)%x->N]] /pdist;
  }

  //Calcul de la puissance global:
  Puis = 0;
  for( hp=0; hp<x->N; hp++)
    Puis += (float)pow( g[hp]/x->dst_hp[x->rev[hp]], 2 );

  //Affectation dans la dataspace avec normalisation :
  for( hp=0; hp<x->N; hp++) 
    x->G0[hp] = (float)(g[hp]/(sqrt(2*Puis)*x->r_c));


  return;
}

/**********************************************************************/
/*                       METHODE DSP                                  */
/**********************************************************************/

void vbapan_tilde_dsp(t_vbapan_tilde *x, t_signal **sp, short *count)
{
	long i;
	t_int **sigvec;
	int pointer_count;
	for(i=0; i<3; i++) x->connected[i] = count[i];
	
	pointer_count = x->Nout + 5; // object pointer, 3 inlet, all outlet and vec-samps
	
	sigvec  = (t_int **) calloc(pointer_count, sizeof(t_int *));
	
	for(i = 0; i < pointer_count; i++) sigvec[i] = (t_int *) calloc(sizeof(t_int),1);
	
	sigvec[0] = (t_int *)x; // first pointer is to the object
	
	sigvec[pointer_count - 1] = (t_int *)sp[0]->s_n; // last pointer is to vector size (N)
	
	for(i = 1; i < pointer_count-1; i++) sigvec[i] = (t_int *)sp[i-1]->s_vec;  // now attach the 3 inlets and all outlet
	
	dsp_addv(vbapan_tilde_perform_signal, pointer_count, (void **) sigvec); 
	free(sigvec);
}

//---------------------------------------------------------------------//

void vbapan_tilde_dsp64(t_vbapan_tilde *x, t_object *dsp64, short *count, double samplerate, long maxvectorsize, long flags)
{
	int i;
	for(i=0; i<3; i++) x->connected[i] = count[i];
	object_method(dsp64, gensym("dsp_add64"), x, vbapan_tilde_perform_signal64, 0, NULL);
}

//---------------------------------------------------------------------//

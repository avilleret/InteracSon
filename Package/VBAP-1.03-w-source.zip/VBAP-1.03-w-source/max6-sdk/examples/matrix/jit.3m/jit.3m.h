/* 
	Copyright 2001 - Cycling '74
	Joshua Kit Clayton jkc@cycling74.com	
*/

#ifndef _JIT_3M_H_
#define _JIT_3M_H_



#endif //_JIT_3M_H_

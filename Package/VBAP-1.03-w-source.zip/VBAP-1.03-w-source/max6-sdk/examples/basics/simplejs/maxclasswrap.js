// this file must be copied in the C74:/jsextensions folder
// in order to make SimpleJS class accessible

maxclasswrap("simplejs","SimpleJS");

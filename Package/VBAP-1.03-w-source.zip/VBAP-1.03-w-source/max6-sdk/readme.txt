SDK files cannot be republished without the permission of Cycling ’74.
This repository is provided so that you may include a link to it as a git submodule within projects.

For documentation, please see:
http://cycling74.com/sdk/MaxSDK-6.1.4/html/index.html

For support, please use the developer forums at:
http://cycling74.com/forums/

You can download the entire SDK and documentation from:
http://cycling74.com/products/sdk/

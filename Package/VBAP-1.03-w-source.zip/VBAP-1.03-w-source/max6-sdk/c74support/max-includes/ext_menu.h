#ifndef _EXT_MENU_H_
#define _EXT_MENU_H_

// 	NOTE: This file is obsolete.

#endif /* _EXT_MENU_H_ */
